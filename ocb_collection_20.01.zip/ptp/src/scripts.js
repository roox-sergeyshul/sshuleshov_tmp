window.pageData = {};
window.pageData.haveResponse = false;
var pageurl = document.location.href;
var query_string = pageurl.split('n=');
var param_n = query_string[1];
window.pageData.n = param_n;
//console.log('param_n: ' + param_n);
var error = 0,
    myC = {
        beforeShow: function (textbox, instance) {
            var txtBoxOffset = $(this).offset();
            var top = txtBoxOffset.top;
            var left = txtBoxOffset.left;
            var textBoxWidth = $(this).outerWidth();
            ////alert(textbox.offsetHeight);
            //console.log('top: ' + top + 'left: ' + left);
            setTimeout(function () {
                ////console.log(instance);
                instance.dpDiv.css({
                    top: top + 55, //you can adjust this value accordingly
                    left: left + textBoxWidth - 248//show at the end of textBox
                });
            }, 0);
        },
        //changeMonth: true,
        //changeYear: false,
        showOtherMonths: true,
        selectOtherMonths: true,
        dateFormat: "d M yy",
        altFormat: "yy-mm-dd",
        altField: "#alt-date",
        monthNames: [
            "Январь",
            "Февраль",
            "Март",
            "Апрель",
            "Май",
            "Июнь",
            "Июль",
            "Август",
            "Сентябрь",
            "Октябрь",
            "Ноябрь",
            "Декабрь"],
        monthNamesShort: [
            "января",
            "февраля",
            "марта",
            "апреля",
            "мая",
            "июня",
            "июля",
            "августа",
            "сентября",
            "октября",
            "ноября",
            "декабря"],
        closeText: 'Закрыть',
        prevText: '&#x3c;',
        nextText: '&#x3e;',
        currentText: 'Сегодня',
        dayNames: ['воскресенье', 'понедельник', 'вторник', 'среда', 'четверг', 'пятница', 'суббота'],
        dayNamesShort: ['вск', 'пнд', 'втр', 'срд', 'чтв', 'птн', 'сбт'],
        dayNamesMin: ['Вс', 'Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб'],
        weekHeader: 'Нед',
        firstDay: 1,
        isRTL: false,
        showMonthAfterYear: false,
        yearSuffix: '',
        minDate: "0",
        maxDate: "+5"
    };


$(document).ready(function () {
    //if (window.pageData.response.data.acceptedAt == undefined) fillForm();
    $.ajax({
        url: '/webapi/ptps/' + param_n,
        error: function() {
            window.location.href = "http://www.open.ru";
            //console.log('REDIRECT');
        },
        success: function(data, status) {
            window.pageData.response = data;
            //console.log('response: ' + window.pageData.response);
            //console.log(window.pageData.response.data);
            error = 0;
            //console.log('offer id exists, show button or thanks?');
            if (window.pageData.response.data.acceptedAt) {
                //console.log('found "acceptedAt" in response, show thanks');
                window.pageData.haveResponse = true;

                $(document).ready(function () {
                    thankYou();
                });
            } else {
                fillForm();
                //console.log('"acceptedAt" NOT found in response, show button');
                $(document).ready(function () {
                    $('#form__button').fadeIn(300);
                });
            };
            setTimeout(function () {
                $('#preloader').remove();
                $('#form-container').removeClass('hidden');
            }, 1000);

        },
        dataType: 'json'
    });

    $('#form__input-email')
        .select(function(e) {
            window.emailStart = e.target.selectionStart;
            window.emailEnd = e.target.selectionEnd;
           //console.log('Changed: ' + window.emailStart + ' to ' + window.emailEnd);
        })
        .focus(function () {
            window.prevVal = $('#form__input-email').val().replace(/\s/g, '');
            $('#form__input-email').val(window.prevVal);
            setCaretPosition(this, window.prevVal.length);
        })
        .keydown(function(key) {
            if (key.keyCode == 17)//console.log('keydown CTRL');
            window.ctrlPressed = true;
        })
        .keyup(function(key) {
            if (key.keyCode == 17)//console.log('keyup CTRL');
            window.ctrlPressed = false;
        })
        .keypress(function(key) {
            window.emailStart = getCaretPosition(this);
           //console.log('Caret position' + window.emailStart);
            if (controlKeys(key)) return true;
            if (keysAllowedWithCTRL(key)) return true;
            if ((window.emailStart == 0) && (window.emailEnd == 50)){
               //console.log('50/50 Selected, replaced by input');
                return true;
            } else if ($('#form__input-email').val().length+1 >= 51){
    //               //console.log('length+1 == 8');

                return false;
            }
        })
        .on('input', function() {
            if ($('#form__input-email').val().length > 50) {
                $('#form__input-email').val($('#form__input-email').val().replace(/\s/g, '').substr(0,50));
               //console.log('email trimed');
            }
        })
        .blur(function () {
                $('#form__input-email').val($('#form__input-email').val().replace(/\s/g, '').substr(0,50));
    });

/*
    $('#form__input-sum')

*/

    $('#datepicker')
        .click(function () {
            if ($("#ui-datepicker-div").is(":visible") == true) {
                $('#datepicker')
                    .off("click")
                    .click(function () {
                        datepickerHideOn()
                        $('#datepicker').click(function () {
                            datepickerShowOn();
                        })
                    })
            }
        })
        .blur(function () {
            $('#datepicker')
                .off("click")
                .click(function () {
                    datepickerShowOn();
                })
        })
        .change(function () {
            validateDate();
        });

    $('#form__input-paymethod')
        .click(function () {
            selectShowOn();
            if ($("#form__paymethods").is(":visible") == true) {
                //$('#form__input-paymethod').off("click");
                $('#form__input-paymethod').click(function () {
                    selectHideOn()
                    $('#form__input-paymethod').click(function () {
                        selectShowOn();
                    })
                })
            }
        })
        .blur(function () {
            $('#form__input-paymethod')
                .off("click")
                .click(function () {
                    selectShowOn();
                })
        })

        .change(function () {
            validatePayMethod();
        });
    $('.form__div-select-option').click(function () {
        $('#form__input-paymethod').val(this.innerHTML);
        $('#form__paymethods').fadeOut(200);
        event.preventDefault();
    });

    $(document).focusout(function () {
        $('#form__paymethods').fadeOut(150);
    });

    $('#form__button').click(function () {
        //e.preventDefault();
        var data = getFormData();
        if ((data.sum == '') || (data.date == '') || (data.method == '')) {
            //validateEMail();
            validateSum();
            validateDate();
            validatePayMethod();
        } else {
            /*if (/!*validateEMail() &&*!/ validateSum() && validateDate() && validatePayMethod())
                sendData();
            */
            var dataToSend = stringifyFormData();
            //console.log(dataToSend);
            $.ajax({
                type: "POST",
                headers: {
                    'Accept': 'application/json',
                    'Content-Type': 'application/json'
                },
                url: '/webapi/ptps/' + window.pageData.n + '/acceptance',
                data: dataToSend,
                success: function (data) {
                    window.pageData.response = data;
                    ////alert('success ' + dateToSend);
                    thankYou();
                },
                dataType: 'json'
            });
        }
    });
    $(function () {
        //$("#datepicker").datepicker(myC);
    });
});

function controlKeys(key) {
    if (   key.key == 'ArrowLeft' /*keyCode: 37, key: "ArrowLeft", charCode: 0*/
        || key.keyCode == 39 /*keyCode: 39, key: "ArrowRight", charCode: 0*/
        || key.keyCode == 46 /*keyCode: 46, key: "Delete", charCode: 0*/
        || key.keyCode == 8 /*keyCode: 8, key: "Backspace", charCode: 0*/
        || key.key == 'F5' /*keyCode: 116, key: "F5", charCode: 0*/
        || key.key == 'End' /*keyCode: 35, key: "End", charCode: 0*/
        || key.key == 'Home' /*keyCode: 36, key: "Home", charCode: 0*/
            //|| key.key == 'ArrowLeft'
            //|| key.key == 'Delete'
        || key.keyCode == 9 /*keyCode: 9, key: "Tab", charCode: 0*/) {

       //console.log('Control key pressed');
       //console.log('key.key = '+key.key+'; key.keyCode = '+key.keyCode);
        return true;
    } else return false;
}

function notAllowedKeys(key) {
    if ((key.key == 'ArrowLeft' /*keyCode: 37, key: "ArrowLeft", charCode: 0*/
        || key.keyCode == 39 /*keyCode: 39, key: "ArrowRight", charCode: 0*/
        || key.key == 'End' /*keyCode: 35, key: "End", charCode: 0*/
        || key.key == 'Home' /*keyCode: 36, key: "Home", charCode: 0*/
        || key.keyCode == 46 /*keyCode: 46, key: "Delete", charCode: 0*/
        || key.keyCode == 35 /*keyCode: 0, key: "#", charCode: 35*/
        || key.keyCode == 36 /*keyCode: 0, key: "$", charCode: 36*/
        || key.keyCode == 37 /*keyCode: 0, key: "%", charCode: 37*/
        || key.keyCode == 44 /*keyCode: 0, key: ",", charCode: 44*/
        || key.keyCode == 46 /*keyCode: 0, key: ".", charCode: 46*/
        || key.keyCode == 229 /*android keys keyCode*/)
   /*     || key.key == '`'
        || key.key == '~'
        || key.key == '!'
        || key.key == '@'
        || key.key == '#'
        || key.key == '№'
        || key.key == '%'
        || key.key == ':'
        || key.key == '^'
        || key.key == '&'
        || key.key == '*'
        || key.key == '-'
        || key.key == '_'
        || key.key == '='
        || key.key == '+'
        || key.key == '/'
        || key.key == '\\'
        || key.key == '|'
        || key.key == '.'
        || key.key == ','
        || key.key == '$'
        || key.key == '?'
        || key.key == '('
        || key.key == ')'
        || key.key == '"'
        || key.key == '\''

        || key.char == '`'
        || key.char == '~'
        || key.char == '!'
        || key.char == '@'
        || key.char == '#'
        || key.char == '№'
        || key.char == '%'
        || key.char == ':'
        || key.char == '^'
        || key.char == '&'
        || key.char == '*'
        || key.char == '-'
        || key.char == '_'
        || key.char == '='
        || key.char == '+'
        || key.char == '/'
        || key.char == '\\'
        || key.char == '|'
        || key.char == '.'
        || key.char == ','
        || key.char == '$'
        || key.char == '?'
        || key.char == '('
        || key.char == ')'
        || key.char == '"'
        || key.char == '\''


        || key.keyCode == 229
      /!*  || key.keyCode < 48
        || key.keyCode > 57*!/
        /!*|| key.charCode < 48
        || key.charCode > 57*!/)
        || (key.keyCode < 48 || key.keyCode > 57)
        && (key.keyCode < 96 || key.keyCode > 105 )*/) {
        //console.log('KEY NOT ALLOWED (key.keyCode < 48 || key.keyCode > 57)');
       //console.log('KEY NOT ALLOWED key.key = '+key.key+'; key.keyCode = '+key.keyCode+'; key.charCode = '+key.charCode+'; key.char = '+key.char);
        return true;
    } else return false;
}

function allowedKeys(key) {
    if (   key.key == '0'
        || key.key == '1'
        || key.key == '2'
        || key.key == '3'
        || key.key == '4'
        || key.key == '5'
        || key.key == '6'
        || key.key == '7'
        || key.key == '8'
        || key.key == '9') {
            return true;
        } else return false;
}


function keysAllowedWithCTRL(key) {
    if (   key.charCode == 120 /*keyCode: 0, key: "x", charCode: 120*/
        || key.charCode == 99 /*keyCode: 0, key: "c", charCode: 99*/
        || key.charCode == 118 /*keyCode: 0, key: "v", charCode: 118*/
        || key.charCode == 97 /*keyCode: 0, key: "a", charCode: 97*/
        || key.charCode == 121
        || key.charCode == 122) {
        if (window.ctrlPressed) {
            //console.log(key.key + ' with CTRL pressed');
           //console.log('key.charCode = '+key.charCode);
            return true;
        } else return false;
    } else return false;
}

function rusMonth(month) {
    switch (month) {
        case 0:
            s = "января";
            break;
        case 1:
            s = "февраля";
            break;
        case 2:
            s = "марта";
            break;
        case 3:
            s = "апреля";
            break;
        case 4:
            s = "мая";
            break;
        case 5:
            s = "июня";
            break;
        case 6:
            s = "июля";
            break;
        case 7:
            s = "августа";
            break;
        case 8:
            s = "сентября";
            break;
        case 9:
            s = "октября";
            break;
        case 10:
            s = "ноября";
            break;
        case 11:
            s = "декабря";
            break;
    }
    return s;
}

function numberOfOption(textOfOption) {
    switch (textOfOption) {
        case 'Перевод из другого банка':
            s = 1;
            break;
        case 'Отделение/банкомат банка':
            s = 2;
            break;
        case 'Интернет банк':
            s = 3;
            break;
        case 'Другое':
            s = 4;
            break;
    }
    return s;
}

function validatePayMethod() {
    val = $('#form__input-paymethod').innerHTML;
    if (val == '') {
        $('#form__paymethod-error').html('Поле заполнено неправильно').addClass('form__input-validation-message--error');
        $('#form__input-paymethod').addClass('form__input--error');
        return false;
    }
    ;
    if (val != '') {
        $('#form__paymethod-error').html('&nbsp;').removeClass('form__input-validation-message--error');
        $('#form__input-paymethod').removeClass('form__input--error');
        return true;
    }
    ;
}

function validateDate() {
    val = $('#datepicker').val();
    if (val == '') {
        $('#form__date-error').html('Укажите предполагаемую дату платежа').addClass('form__input-validation-message--error');
        $('#datepicker').addClass('form__input--error');
        return false;
    }
    ;
    if (val != '') {
        $('#form__date-error').html('&nbsp;').removeClass('form__input-validation-message--error');
        $('#datepicker').removeClass('form__input--error');
        return true;
    }
    ;
}

function validateSum() {
    clearTimeout(window.timer);
    var val = $('#form__input-sum').val().replace(/[^0-9\-.]|([0-9\-.]+)-|(\.[0-9]*)\.|(^-?0)0|^\./, '$1$2$3').replace(/\s+/g, '').replace(/-/g, '');
    //val = parseInt(val).toFixed(2);
    if (isNaN(val)) {
        $('#form__input-sum').val((window.sum));
        $('#form__sum-error').html('Можно вводить только цифры').addClass('form__input-validation-message--error');
        $('#form__input-sum').addClass('form__input--error');
        window.timer = setTimeout(function() {
            $('#form__sum-error').html('Установлено рекомендуемое значение').addClass('form__input-validation-message--error');
            window.x = $('#form__input-sum').val().replace(/\s/g, '');
           //console.log('CHANGE! get new window.x.length = '+window.x.length);
            window.timer = setTimeout(function() {
                $('#form__input-sum').removeClass('form__input--error');
                $('#form__sum-error').html('&nbsp;').removeClass('form__input-validation-message--error');
            }, 3000);
        }, 2000);
        return false;
    }
    ;
    if (val == '') {
        $('#form__sum-error').html('Введите сумму').addClass('form__input-validation-message--error');
        $('#form__input-sum').addClass('form__input--error');
        return false;
    }
    ;
    if (((val > 0) && (val < 500)) || (val <= 0)) {
        $('#form__sum-error').html('Сумма не может быть меньше 500 рублей').addClass('form__input-validation-message--error');
        $('#form__input-sum').addClass('form__input--error');
        window.timer = setTimeout(function() {
            $('#form__input-sum').val(500);
            $('#form__input-sum').removeClass('form__input--error');
            $('#form__sum-error').html('&nbsp;').removeClass('form__input-validation-message--error');
            window.x = $('#form__input-sum').val().replace(/\s/g, '');
           //console.log('CHANGE! get new window.x.length = '+window.x.length);
        }, 3000);
        return false;
    }
    ;

    if (val > 3000000) {
        $('#form__sum-error').html('Сумма не может быть больше 3 000 000 рублей').addClass('form__input-validation-message--error');
        $('#form__input-sum').addClass('form__input--error');
        window.timer = setTimeout(function() {
           //console.log('timer');
            if (window.inputFocused) {
                $('#form__input-sum').val(window.sum);
            } else {
                $('#form__input-sum').val(addSpaces(window.sum));
            }
            $('#form__input-sum').removeClass('form__input--error');
            $('#form__sum-error').html('&nbsp;').removeClass('form__input-validation-message--error');
            window.x = $('#form__input-sum').val().replace(/\s/g, '');
           //console.log('CHANGE! get new window.x.length = '+window.x.length);
        }, 3000);
    } else if (val > window.sum) {
        $('#form__sum-error').html('Сумма не может быть больше задолженности').addClass('form__input-validation-message--error');
        $('#form__input-sum').addClass('form__input--error');
        window.timer = setTimeout(function() {
            if (window.inputFocused) {
                $('#form__input-sum').val(window.sum);
            } else {
                $('#form__input-sum').val(addSpaces(window.sum));
            }
            $('#form__input-sum').removeClass('form__input--error');
            $('#form__sum-error').html('&nbsp;').removeClass('form__input-validation-message--error');
            window.x = $('#form__input-sum').val().replace(/\s/g, '');
           //console.log('CHANGE! get new window.x.length = '+window.x.length);
        }, 3000);
        return false;
    }
    ;
    if ((val <= 3000000) && (val >= 500)) {
        $('#form__sum-error').html('&nbsp;').removeClass('form__input-validation-message--error');
        $('#form__input-sum').removeClass('form__input--error');//.val(addSpaces(val));
        return true;
    }
    ;
}

function validateEMail() {
    val = $('#form__input-email').val();
    if (val.replace(/\s+/g, '') != '') {
        if (!/.+@.+\..+/i.test(val)) {
            $('#form__email-error').html('Укажите адрес электронной почты').addClass('form__input-validation-message--error');
            $('#form__input-email').addClass('form__input--error');
            return false;
        } else {
            $('#form__email-error').html('&nbsp;').removeClass('form__input-validation-message--error');
            $('#form__input-email').removeClass('form__input--error');
            return true;
        }
    } else {
        $('#form__email-error').html('&nbsp;').removeClass('form__input-validation-message--error');
        $('#form__input-email').removeClass('form__input--error');
        return true;
    }
}

function checkFill() {
    if (($('#form__input-sum').val().replace(/\s+/g, '') == '')
       ||$('#datepicker').val() == '') {
        ptplog('That bug!');
        ptplog("$('#form__input-sum').val() = "+$('#form__input-sum').val());
        ptplog("$('#datepicker').val() = "+$('#datepicker').val());
        return false;
    } else {
        ptplog('no bug');
        ptplog("$('#form__input-sum').val() = "+$('#form__input-sum').val());
        ptplog("$('#datepicker').val() = "+$('#datepicker').val());
        return true;
    }
}

function getISODate(v) {
    //console.log(v);
    var d = new Date(v);
    var n = d.toISOString();
    return n;
}

function getFormData() {
    var formData = {
        paymentDate: getISODate($('#alt-date').val()),
        paymentType: numberOfOption($('#form__input-paymethod').val()).toString(),
        paymentAmount: $('#form__input-sum').val().replace(/\s+/g, ''),
        contactMail: $('#form__input-email').val()
    };
    ////console.log(formData.date);
    return formData;
}

function stringifyFormData() {
    return JSON.stringify(getFormData());
}

function addSpaces(number) {
    var str = String(number);
    var num = str.replace(/(\d)(?=(\d\d\d)+([^\d]|$))/g, '$1 ');
    return num;
}

function thankYou() {
    $('#form-container').remove();
    $('#success-container').removeClass('hidden');
}

/*function sendData() {
    data = stringifyFormData();
    com.rooxteam.statistic.client.logOperationSync('form.submit', data, 1, null, null, function () {
       //console.log('done,' + data);
        thankYou();
    });
}*/

function parseURL(pageurl) {

    var query_string = pageurl.split('n=');
    var vars = query_string[1].split('&d=');
    var id = vars[0];
    var sum = vars[1];
    ////alert(query_string[1]);
    var URL = {
        id: id,
        sum: parseInt(sum, 16)
    };
    return URL;
}

function fillForm() {
    var formData = parseURL(document.location.href);
    //$('#form__input-sum').val(addSpaces(window.pageData.response.data.debt));
    $('.form__label-text').eq(0).parent().append(
        $('<input/>').attr({
            'type': 'text',
            'class': 'form__input',
            'id': 'form__input-sum',
            'autocomplete': 'off',
            'readonly': false,
            'value': addSpaces(window.pageData.response.data.debt)
        }).select(function(e) {
                window.sumStart = e.target.selectionStart;
                window.sumEnd = e.target.selectionEnd;
                //console.log('Changed: ' + window.sumStart + ' to ' + window.sumEnd);
            })
            .focus(function () {
                //console.log('focus');
                window.prevVal = $('#form__input-sum').val().replace(/\s/g, '');
                $('#form__input-sum').val(window.prevVal);
                setCaretPosition(this, window.prevVal.length);
                window.x = window.prevVal;
                //console.log('window.x.length = '+window.x.length);
                ptplog('Focus!');
                ptplog("$('#form__input-sum').val() = "+$('#form__input-sum').val());
                ptplog("$('#datepicker').val() = "+$('#datepicker').val());
            })

            .on('click touchstart touchend touchmove touchcancel', function () {

                setCaretPosition(this, $(this).val().replace(/\s/g, '').length);
            })

            .keydown(function(key) {
                //key.preventDefault();
                //alert('keydown event');
                //console.log('KEYDOWN key.key = '+key.key+'; key.keyCode = '+key.keyCode+'; key.charCode = '+key.charCode);
                window.sumStart = getCaretPosition(this);
                //console.log('Caret position' + window.sumStart);
                //console.log(key);
                window.beforeinput = $('#form__input-sum').val().replace(/\s/g, '');
                //if (allowedKeys(key)) return true;
                //if (controlKeys(key)) return true;
                //if (keysAllowedWithCTRL(key)) return true;
                if (key.keyCode == 8) {
                    return true;
                }
                if (notAllowedKeys(key)) {
                    key.preventDefault();
                    return false;
                }
                if ((window.sumStart == 0) && (window.sumEnd == 7)){
                    //console.log('7/7 Selected, replaced by input');
                    return true;
                } else  if ($('#form__input-sum').val().replace(/\s/g, '').length+1 >= 8){
//               //console.log('length+1 == 8');
                    return false;
                }
            })
            .keyup(function(key) {
                if (key.keyCode == 8) {
                    return true;
                }
                //alert('keyup event');
                //console.log('KEYUP key.key = '+key.key+'; key.keyCode = '+key.keyCode+'; key.charCode = '+key.charCode);
                if (key.keyCode == 17) {
                    //console.log('keyup CTRL');
                    window.ctrlPressed = false;
                }
                if (notAllowedKeys(key)) {
                    key.preventDefault();
                    return false;}
            })

            .on('input', function(key) {
                var inputText = $('#form__input-sum').val();

                var resultText = inputText.replace(/[^0-9]/g, '');
                $('#form__input-sum').val(resultText);

                //console.log('Input happened! window.x.length = '+window.x.length);
                var x = $('#form__input-sum').val().replace(/\s/g, '');
                //console.log(x);
                var diff = parseInt(x.length) - parseInt(window.x.length);
                //console.log('x.length = ' + x.length );
                //console.log('window.x.length = ' + window.x.length );
                //console.log('x.length - window.x.length = ' + diff );
                if ( diff != 1 && diff != -1) {
                    //console.log('CTRL+V detected!');
                    window.ctrlvDetected = true;
                }
                if (x.indexOf('.')!=-1) $('#form__input-sum').val(parseInt(x));
                if (x.length>7) {
                    $('#form__input-sum').val(window.beforeinput);
                }
                window.inputFocused = true;
                validateSum();
                window.x = $('#form__input-sum').val().replace(/\s/g, '');
                //console.log('get new window.x.length = '+window.x.length);
                window.ctrlvDetected = false;
            })

            .blur(function () {
                window.inputFocused = false;
                $('#form__input-sum').val(addSpaces(parseInt($('#form__input-sum').val())));
                validateSum();
            }),
        $('<div/>').attr({
            'class': 'form__input-validation--message',
            'id': 'form__sum-error'
        }).text('&nbsp;')
    );

    $('.form__label-text').eq(1).parent().append(
        $('<input/>').attr({
            'type': 'text',
            'class': 'form__input',
            'id': 'datepicker',
            'autocomplete': 'off',
            'readonly': true
        }).datepicker(myC),
        $('<div/>').attr({
            'class': 'form__input-validation--message',
            'id': 'form__date-error'
        }).text('&nbsp;')
    );
    $('#id').val(window.pageData.response.data.id);
    $('#greeting-sum').html('Ваша задолженность составляет <br><span class="blue-text">' + addSpaces(window.pageData.response.data.debt) + '</span>&nbsp;<span class="rouble--small"></span>');
    window.sum = window.pageData.response.data.debt;
    var today = new Date();
    var month = today.getMonth()+1;
    $('#datepicker').val(today.getDate() + ' ' + rusMonth(month-1) + ' ' + today.getFullYear());
    $('#alt-date').val(today.getFullYear() + '-' + checkDateNumber(month) + '-' + checkDateNumber(today.getDate()));
}

function checkDateNumber(d) {
    if (d<=9) {
        return '0'+d;
    } else return d;
}

function getCaretPosition(element) {
    var CaretPos = 0;
    // IE Support
    if (document.selection) {

        element.focus();
        var Sel = document.selection.createRange();

        Sel.moveStart('character', -element.value.length);

        CaretPos = Sel.text.length;
    }
    // Firefox support
    else if (element.selectionStart || element.selectionStart == '0')
        CaretPos = element.selectionStart;
    return (CaretPos);
}

function setCaretPosition(element, pos) {

    if (element.setSelectionRange) {
        element.focus();
        element.setSelectionRange(pos, pos);
    }
    else if (element.createTextRange) {
        var range = element.createTextRange();
        range.collapse(true);
        range.moveEnd('character', pos);
        range.moveStart('character', pos);
        range.select();
    }
}

function datepickerHideOn() {
    $('#datepicker')
        .datepicker("hide")
        .off("click")
        .click(function () {
            datepickerShowOn();
        })
        .blur();
}

function datepickerShowOn() {
    $('#datepicker')
        .datepicker("show")
        .off("click")
        .click(function () {
            datepickerHideOn();
        });
}

function selectHideOn() {
    $('#form__paymethods').fadeOut(200);
    $('#form__input-paymethod')
        .off("click")
        .click(function () {
            selectShowOn();
        })
        .blur();
}

function selectShowOn() {
    var input = $('#form__input-paymethod');
    $('#form__paymethods')
        .fadeIn(200)
        .width(input.width() + 24);
    $('#form__paymethod-error').html('&nbsp;').removeClass('form__input-validation-message--error');
    input
        .removeClass('form__input--error')
        .off("click")
        .click(function () {
            selectHideOn();
        });
}

function ptplog(param) {
    //console.re.log(param);
    //console.log(param);
}
