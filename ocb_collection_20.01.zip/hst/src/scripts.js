window.pageData = {};
window.pageData.haveResponse = false;
var pageurl = document.location.href;
var query_string = pageurl.split('n=');
var param_n = query_string[1];
window.pageData.n = param_n;
//console.log('param_n: ' + param_n);
var error = 0;
$.ajax({
    url: '/webapi/hstOffers/' + param_n,
    error: function() {
        window.location.href = "http://www.open.ru";
    },
    success: function(data, status) {
        window.pageData.response = data;
       //console.log('response: ' + window.pageData.response);
       //console.log(window.pageData.response);
                error = 0;
               //console.log('offer id exists, show button or thanks?');
                fillInitialVals();
                setDates(window.pageData.response.data.acceptedAt);
                fillDates();
                if (window.pageData.response.data.acceptedAt) {
                   //console.log('found "acceptedAt" in response, show thanks');
                   //console.log('SETTING date: '+window.pageData.response.data.acceptedAt);
                    window.pageData.haveResponse = true;

                    window.pageData.sliderEnabled = true;
                    setSlider();
                    window.pageData.sliderEnabled = false;
                    $(document).ready(function () {
                        thankYou();
                    });
                } else {
                   //console.log('"acceptedAt" NOT found in response, show button');
                    handleTicks('#tick1');
                    window.pageData.sliderEnabled = true;
                    $(document).ready(function () {
                        $('#form__button').fadeIn(300);
                    });
                };
                    setTimeout(function () {
                        $('#preloader').remove();
                        $('#form-container').removeClass('hidden');
                    }, 1000);

    },
    dataType: 'json'
});

$(document).ready(function () {
    window.pageData.sliderMax = 200;
    window.pageData.sliderMiddle = 100;
    window.pageData.sliderMin = 0;
    var html5Slider = document.getElementById('slider');
    window.pageData.slider = html5Slider;
    noUiSlider.create(html5Slider, {
        start: 0,
        connect: [true, false],
        behaviour: 'tap-drag',
        step: 1,
        snap: false,
        range: {
            'min': window.pageData.sliderMin,
            'max': window.pageData.sliderMax
        }
    });

    html5Slider.noUiSlider.on('change', function (values, handle) {
        var v = html5Slider.noUiSlider.get();
        handleSlider(html5Slider, v, false);
    });
    $('#timeFrame1').click(function() {
        handleSlider(html5Slider, false, window.pageData.sliderMin);
    });
    $('#timeFrame2').click(function () {
        handleSlider(html5Slider, false, window.pageData.sliderMiddle);
    });
    $('#timeFrame3').click(function () {
        handleSlider(html5Slider, false, window.pageData.sliderMax);
    });
    $('#form__button').click(function () {
       //alert('button should work');
        var dataToSend = stringifyFormData();
      //console.log(dataToSend);
        $.ajax({
            type: "POST",
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json'
            },
            url: '/webapi/hstOffers/' + window.pageData.n + '/accept',
            data: dataToSend,
            success: function (data) {
                window.pageData.response = data;
                //alert('success ' + dateToSend);
                thankYou();
            },
            dataType: 'json'
        });
    });
});

$(window).resize(function () {
    var html5Slider = document.getElementById('slider');
    var v = html5Slider.noUiSlider.get();
    handleSlider(html5Slider, v, false);
});

function calculateDiscount() {
    if (window.pageData.response.data.timeFrame == '1-2d') {
        var k = 1;
    }
    if (window.pageData.response.data.timeFrame == '3-4d') {
        var k = .7;
    }
    if (window.pageData.response.data.timeFrame == '5d') {
        var k = .5;
    }
    var discount = (window.pageData.response.data.penalty * k).toFixed();
    $('#main__result-discount-value').html(addSpaces(discount));
    $('#discount-step3').html(addSpaces(discount));
    return discount;
}

function calculatePayment() {
    var payment = (window.pageData.response.data.debt + window.pageData.response.data.penalty - calculateDiscount()).toFixed();
    $('#main__result-sum-value').html(addSpaces(payment));

    $('#sum-step1').html(addSpaces(payment));
    return payment;
}

function handleSlider(html5Slider, currPos, moveTo) {
    if (window.pageData.sliderEnabled == true) {
        if ((currPos == false) && (moveTo != false)) {
            currPos = moveTo;
        }
        var fine = window.pageData.response.data.penalty;
        if (currPos <= 60) {
            //alert(v);
            var discountFine = fine * 1;
            var timeFrame = '1-2d';
            html5Slider.noUiSlider.set(0);
            fine = fine - discountFine;
            $('#chosenDate').val(window.pageData.date12d.getDate() + '.' + (window.pageData.date12d.getMonth() + 1 ) + '.' + window.pageData.date12d.getFullYear());
            handleTicks('#tick1');
        }
        if ((currPos > 60) && (currPos <= 140)) {
            var discountFine = fine * .7;
            var timeFrame = '3-4d';
            html5Slider.noUiSlider.set(100);
            fine = fine - discountFine;
            $('#chosenDate').val(window.pageData.date34d.getDate() + '.' + (window.pageData.date34d.getMonth() + 1 ) + '.' + window.pageData.date34d.getFullYear());
            handleTicks('#tick2');
        }
        if ((currPos > 140) && (currPos <= 200)) {
            var discountFine = fine * .5;
            var timeFrame = '5d';
            html5Slider.noUiSlider.set(200);
            fine = fine - discountFine;
            $('#chosenDate').val(window.pageData.date5d.getDate() + '.' + (window.pageData.date5d.getMonth() + 1 ) + '.' + window.pageData.date5d.getFullYear());
            handleTicks('#tick3');
        }
        // calculatePayment();
        var pay = ((window.pageData.response.data.debt + window.pageData.response.data.penalty) - discountFine).toFixed();
        $('#main__result-sum-value').html(addSpaces(pay));
        // calculateDiscount();
        var discount = discountFine.toFixed();
        $('#main__result-discount-value').html(addSpaces(discount));
        $('#timeFrame').val(timeFrame);
        $('#chosenSum').val(addSpaces((window.pageData.response.data.debt + fine).toFixed()));
    }
    return false;
}

function handleTicks(tickId) {
    if (document.documentElement.clientWidth <= 640) {
        $(tickId).addClass('shortTick').siblings().removeClass('shortTick');
    } else $('.shortTick').removeClass('shortTick');
    if (tickId == false) $('.shortTick').removeClass('shortTick');
}

function scrollToSteps() {
    var scrollHeight = $('.container').height(),
        $htmlBody = $("html, body");
    //alert(scrollHeight);
    $htmlBody.animate({
        scrollTop: scrollHeight
    }, 1000);
}

function thankYou() {
    //$('#form__button').attr('disabled', 'disabled').css("background-color", "#cccccc");
    $('#slider').css("background", "#cccccc");
    $('.noUi-handle').fadeOut();
    setTimeout(function () {
        $('.noUi-handle').addClass("grey--blocked").fadeIn(300);
        $('.noUi-connect, .noUi-base').addClass("grey--blocked");
    }, 200);
    $('.noUi-base').unbind();
    $('#form__button').fadeOut(400);
    setTimeout(function () {
        $('#form__button').remove();
        $('#success-container').slideDown(200);
        scrollToSteps();
    }, 500);
    //$('#success-container').fadeIn(200);
    window.pageData.sliderEnabled = false;
    //alert('thankyou: '+window.pageData.sliderEnabled);
    window.pageData.slider.noUiSlider.off('change');
    //handleTicks(false);
    //var slider = window.pageData.slider;
    window.pageData.slider.setAttribute('disabled', true);
    calculatePayment();
    calculateDiscount();
    getChosenDate();
}

function getChosenDate() {
    var t = new Date();
    //alert(window.pageData.response.data.timeFrame);
    if (window.pageData.response.data.timeFrame == '1-2d') {
        t = window.pageData.date12d;
    }
    if (window.pageData.response.data.timeFrame == '3-4d') {
        t = window.pageData.date34d;
    }
    if (window.pageData.response.data.timeFrame == '5d') {
        t = window.pageData.date5d;
    }
    $('#result-date').html(t.getDate() + '.' + (t.getMonth()+1 ) + '.' + t.getFullYear());
}

function parseURL(pageurl) {

    var query_string = pageurl.split('n=');
    if (query_string[1] != undefined) {
        var param_n = query_string[1];
        var params = {
            n: param_n
        };
    }
    return params;
}

function setSlider() {
    var tf = window.pageData.response.data.timeFrame;
    if (tf) {
      //console.log('Setting slider to: ' + tf);
        var mt;
        if (tf == '1-2d') mt = window.pageData.sliderMin;
        if (tf == '3-4d') mt = window.pageData.sliderMiddle;
        if (tf == '5d') mt = window.pageData.sliderMax;
        var html5Slider = document.getElementById('slider');
        handleSlider(html5Slider, false, mt);
    }
    return false;
}

function fillDates() {
  //console.log('Filling Dates');

    $('#timeFrame1').html('До ' + window.pageData.date12d.getDate() + ' ' + rusMonth(window.pageData.date12d.getMonth()));
    $('#timeFrame2').html('До ' + window.pageData.date34d.getDate() + ' ' + rusMonth(window.pageData.date34d.getMonth()));
    $('#timeFrame3').html('До ' + window.pageData.date5d.getDate() + ' ' + rusMonth(window.pageData.date5d.getMonth()));
    $('#result-date').html(window.pageData.date12d.getDate() + '.' + (window.pageData.date12d.getMonth() ) + '.' + window.pageData.date12d.getFullYear());
    return false;
}

function setDates(currentDate) {
    if (!currentDate)  currentDate = new Date();
    var date = new Date((currentDate));
  //console.log('SETTING date. Base date: ' + date);
    if (date) {
        window.pageData.date12d = new Date();
        window.pageData.date34d = new Date();
        window.pageData.date5d = new Date();
        window.pageData.date12d.setTime(date.getTime() + 1000 * 60 * 60 * 24 * 2);
        window.pageData.date34d.setTime(date.getTime() + 1000 * 60 * 60 * 24 * 4);
        window.pageData.date5d.setTime(date.getTime() + 1000 * 60 * 60 * 24 * 5);
    }
    return false;
}

function fillInitialVals() {
    $('#greeting-sum-value').html(addSpaces(window.pageData.response.data.penalty));
    // calculatePayment();
    // calculateDiscount();
    $('#main__result-sum-value').html(addSpaces(window.pageData.response.data.debt));
    $('#main__result-discount-value').html(addSpaces(window.pageData.response.data.penalty));
}

function getFormData() {
    var formData = {
        //id: $('#id').val(),
        timeFrame: $('#timeFrame').val()//,
        //chosenDate: $('#chosenDate').val(),
        //chosenSum: $('#chosenSum').val()
    };
    /*    var formDataNew = {
     id: $('#id').val(),
     timeFrame: $('#timeFrame').val(),
     chosenDate: $('#chosenDate').val(),
     chosenSum: $('#chosenSum').val()
     };*/
   //console.log(JSON.stringify(formDataNew));
  //console.log('this will be sent: ' + JSON.stringify(formData));
    return formData;
}

function stringifyFormData() {
    return JSON.stringify(getFormData());
}

function rusMonth(month) {
    switch (month) {
        case 0:
            s = "января";
            break;
        case 1:
            s = "февраля";
            break;
        case 2:
            s = "марта";
            break;
        case 3:
            s = "апреля";
            break;
        case 4:
            s = "мая";
            break;
        case 5:
            s = "июня";
            break;
        case 6:
            s = "июля";
            break;
        case 7:
            s = "августа";
            break;
        case 8:
            s = "сентября";
            break;
        case 9:
            s = "октября";
            break;
        case 10:
            s = "ноября";
            break;
        case 11:
            s = "декабря";
            break;
    }
    return s;
}

function addSpaces(number) {
    var str = String(number);
    var num = str.replace(/(\d)(?=(\d\d\d)+([^\d]|$))/g, '$1 ');
    return num;
}
