This is only a placeholder. You can use this directory for storing global extensions.
However, try to use locally installed extensions instead (in typo3conf/ext/) in order 
to keep the TYPO3 core directory clean of user defined contents.
