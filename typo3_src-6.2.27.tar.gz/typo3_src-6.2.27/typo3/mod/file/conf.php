<?php
$MLANG['default']['tabs_images']['tab'] = 'file.gif';
$MLANG['default']['ll_ref'] = 'LLL:EXT:lang/locallang_mod_file.xlf';
$MCONF['navFrameScript'] = '../../alt_file_navframe.php';
$MCONF['access'] = 'group,user';
$MCONF['name'] = 'file';
$MCONF['workspaces'] = 'online,custom';
