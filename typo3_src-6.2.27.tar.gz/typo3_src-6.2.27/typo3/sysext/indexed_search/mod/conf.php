<?php
$MLANG['default']['tabs_images']['tab'] = 'isearch.gif';
$MLANG['default']['ll_ref'] = 'LLL:EXT:indexed_search/mod/locallang_mod.xlf';
$MCONF['script'] = '_DISPATCH';
$MCONF['access'] = 'admin';
$MCONF['name'] = 'tools_isearch';
